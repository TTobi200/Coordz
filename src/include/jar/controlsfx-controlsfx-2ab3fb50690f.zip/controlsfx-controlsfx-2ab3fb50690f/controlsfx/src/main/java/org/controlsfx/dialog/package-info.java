/**
 * A package containing a powerful (yet easy to use) dialogs API for showing
 * modal dialogs in JavaFX-based applications. 
 */
package org.controlsfx.dialog;